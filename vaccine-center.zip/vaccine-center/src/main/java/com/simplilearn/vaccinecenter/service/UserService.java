package com.simplilearn.vaccinecenter.service;

import com.simplilearn.vaccinecenter.entity.User;
import com.simplilearn.vaccinecenter.entity.VaccineCenter;

import java.util.List;

public interface UserService {
    List<User> getUsers();
    User getUser(Long userId);
}
