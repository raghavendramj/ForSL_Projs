package com.simplilearn.vaccinecenter.service;

import com.simplilearn.vaccinecenter.entity.User;
import com.simplilearn.vaccinecenter.entity.VaccineCenter;

import java.util.List;

public interface VaccineService {
    List<VaccineCenter> getVaccineCenters();

    VaccineCenter getVaccineCenter(Long centerId);

    VaccineCenter save(VaccineCenter vaccinationCenter);

    List<VaccineCenter> getVaccineCentersByCity(String city);
    List<VaccineCenter> getVaccineCentersByState(String state);

    List<String> getVaccineCenterNames();
}
