package com.simplilearn.vaccinecenter.controller;

import com.google.gson.Gson;
import com.simplilearn.vaccinecenter.entity.VaccineCenter;
import com.simplilearn.vaccinecenter.service.VaccineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vaccinecenter")
public class VaccineCenterController {

    @Autowired
    VaccineService vaccineService;

    @PostMapping
    public VaccineCenter saveVaccineCenter(@RequestBody VaccineCenter vaccineCenter) {
        return vaccineService.save(vaccineCenter);
    }

    @GetMapping
    public List<VaccineCenter> getVaccineCenters() {
        return vaccineService.getVaccineCenters();
    }


    @GetMapping("/names")
    public List<String> getVaccineCenterNames() {
        return vaccineService.getVaccineCenterNames();
    }


    @GetMapping("/{centerId}")
    public ResponseEntity<String> getVaccineCenter(@PathVariable Long centerId) {
        VaccineCenter vaccineCenter = vaccineService.getVaccineCenter(centerId);
        if (vaccineCenter == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("VaccineCenter Not found");
        }
        return new ResponseEntity<>(new Gson().toJson(vaccineCenter), HttpStatus.OK);
    }

    @GetMapping("/by/city/{city}")
    public List<VaccineCenter> getVaccineCentersByCity(@PathVariable String city) {
        return vaccineService.getVaccineCentersByCity(city);
    }

    @GetMapping("/by/state/{state}")
    public List<VaccineCenter> getVaccineCentersByState(@PathVariable String state) {
        return vaccineService.getVaccineCentersByState(state);
    }
}
