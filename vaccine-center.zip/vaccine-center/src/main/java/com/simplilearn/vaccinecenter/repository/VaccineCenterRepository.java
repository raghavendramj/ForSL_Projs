package com.simplilearn.vaccinecenter.repository;

import com.simplilearn.vaccinecenter.entity.User;
import com.simplilearn.vaccinecenter.entity.VaccineCenter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VaccineCenterRepository extends JpaRepository<VaccineCenter, Long> {

    List<VaccineCenter> getVaccineCentersByCity(String city);
    List<VaccineCenter> getVaccineCentersByState(String state);
}
