package com.simplilearn.vaccinecenter.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class VaccineCenter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long centerId;
    private String name;
    private String city;
    private String state;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    private List<User> users = new ArrayList<>();

}
