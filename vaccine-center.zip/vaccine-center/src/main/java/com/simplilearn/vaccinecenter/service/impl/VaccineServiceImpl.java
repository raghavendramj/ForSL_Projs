package com.simplilearn.vaccinecenter.service.impl;

import com.simplilearn.vaccinecenter.entity.VaccineCenter;
import com.simplilearn.vaccinecenter.repository.VaccineCenterRepository;
import com.simplilearn.vaccinecenter.service.VaccineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class VaccineServiceImpl implements VaccineService {

    @Autowired
    VaccineCenterRepository vaccineCenterRepository;

    @Override
    public List<VaccineCenter> getVaccineCenters() {
        return vaccineCenterRepository.findAll();
    }

    @Override
    public VaccineCenter getVaccineCenter(Long centerId) {
        Optional<VaccineCenter> optionalVaccineCenter = vaccineCenterRepository.findById(centerId);

        if (optionalVaccineCenter.isPresent())
            return optionalVaccineCenter.get();
        return null;
    }

    @Override
    public VaccineCenter save(VaccineCenter vaccinationCenter) {
        return vaccineCenterRepository.save(vaccinationCenter);
    }

    @Override
    public List<VaccineCenter> getVaccineCentersByCity(String city) {
        return vaccineCenterRepository.getVaccineCentersByCity(city);
    }

    @Override
    public List<VaccineCenter> getVaccineCentersByState(String state) {
        return vaccineCenterRepository.getVaccineCentersByState(state);
    }

    @Override
    public List<String> getVaccineCenterNames() {
        return getVaccineCenters().stream().map(each -> each.getName()).collect(Collectors.toList());
    }
}
